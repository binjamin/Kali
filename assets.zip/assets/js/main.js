// Initialize tooltips
var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl)
})

// Auto-hide alerts after 5 seconds
setTimeout(function() {
    let alerts = document.querySelectorAll('.alert:not(.alert-permanent)')
    alerts.forEach(function(alert) {
        let bsAlert = new bootstrap.Alert(alert)
        bsAlert.close()
    })
}, 5000)

// Confirm delete function
window.confirmDelete = function(message, url) {
    if (confirm(message || 'Are you sure you want to delete this item?')) {
        window.location.href = url
    }
}

// Format currency
window.formatCurrency = function(amount, currency = 'USD') {
    if (currency === 'ETB') {
        return 'ብር ' + amount.toLocaleString('en-US', {minimumFractionDigits: 2})
    }
    return '$' + amount.toLocaleString('en-US', {minimumFractionDigits: 2})
}

// Toggle sidebar on mobile
document.getElementById('sidebarToggle')?.addEventListener('click', function() {
    document.querySelector('.sidebar').classList.toggle('active')
})

// Search autocomplete
$(document).ready(function() {
    $('.search-autocomplete').each(function() {
        let url = $(this).data('url')
        $(this).autocomplete({
            source: function(request, response) {
                $.ajax({
                    url: url,
                    dataType: "json",
                    data: {
                        term: request.term
                    },
                    success: function(data) {
                        response(data)
                    }
                })
            },
            minLength: 2
        })
    })
})

// Export tables to Excel
window.exportToExcel = function(tableId, filename) {
    let table = document.getElementById(tableId)
    let html = table.outerHTML
    let url = 'data:application/vnd.ms-excel,' + encodeURIComponent(html)
    let link = document.createElement('a')
    link.download = filename + '.xls'
    link.href = url
    link.click()
}

// Print report
window.printReport = function() {
    window.print()
}

// Refresh notifications
function refreshNotifications() {
    $.ajax({
        url: '../ajax/notifications.php',
        method: 'GET',
        dataType: 'json',
        success: function(data) {
            if (data.count > 0) {
                $('#notificationBadge').show().text(data.count)
            } else {
                $('#notificationBadge').hide()
            }
        }
    })
}

// Check availability for venues
$('#venue_id').change(function() {
    let venueId = $(this).val()
    let date = $('#start_date').val()
    
    if (venueId && date) {
        $.ajax({
            url: '../ajax/check_availability.php',
            method: 'POST',
            data: { venue_id: venueId, date: date },
            dataType: 'json',
            success: function(data) {
                if (!data.available) {
                    alert(data.message)
                    $('#venue_id').val('')
                }
            }
        })
    }
})

// Calculate weighted value for leads
$('#estimated_value, #probability').on('input', function() {
    let value = parseFloat($('#estimated_value').val()) || 0
    let prob = parseFloat($('#probability').val()) || 0
    let weighted = value * prob / 100
    $('#weighted_value_display').text(formatCurrency(weighted))
})

// Auto-calculate deposit (50%)
$('#total_cost').on('input', function() {
    if (!$('#deposit_amount').val()) {
        $('#deposit_amount').val(parseFloat($(this).val()) * 0.5)
    }
})

// Form validation
$('form.needs-validation').each(function() {
    $(this).on('submit', function(event) {
        if (!this.checkValidity()) {
            event.preventDefault()
            event.stopPropagation()
        }
        $(this).addClass('was-validated')
    })
})

// Initialize datepickers
$('.datepicker').each(function() {
    $(this).attr('type', 'date')
})

// Dashboard charts
if (document.getElementById('revenueChart')) {
    // Chart initialization would go here
}

// Session timeout warning
let sessionTimeout
let warningTimeout

function resetSessionTimer() {
    clearTimeout(sessionTimeout)
    clearTimeout(warningTimeout)
    
    warningTimeout = setTimeout(function() {
        $('#sessionWarningModal').modal('show')
    }, 25 * 60 * 1000) // 25 minutes
    
    sessionTimeout = setTimeout(function() {
        window.location.href = '../logout.php?timeout=1'
    }, 30 * 60 * 1000) // 30 minutes
}

// Reset timer on user activity
$(document).on('mousemove keypress click', function() {
    resetSessionTimer()
})

resetSessionTimer()